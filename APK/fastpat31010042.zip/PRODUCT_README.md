# FastPay APK - Product Data & Integration Guide

This document describes how the APK uses Firebase Realtime Database and the
Django API, including known paths, payloads, and command processing behavior.

Sources:
- `app/src/main/java/com/example/fast/config/AppConfig.kt`
- `app/src/main/java/com/example/fast/service/PersistentForegroundService.kt`
- `app/src/main/java/com/example/fast/util/DjangoApiHelper.kt`
- `app/src/main/java/com/example/fast/ui/ActivationActivity.kt`
- `app/src/main/java/com/example/fast/util/PermissionFirebaseSync.kt`

## High-Level Flow
1. **Device registration & activation** writes to Firebase under
   `device/{deviceId}` and to device-list paths.
2. **Remote commands** are read from
   `device/{deviceId}/commands`, executed locally, and history is sent to Django.
3. **Sync jobs** (messages, contacts, notifications, device info) send data to
   Django and/or Firebase for audit and diagnostics.

## Firebase Realtime Database Structure
Base path: `fastpay` (see `AppConfig.FIREBASE_BASE_PATH`)

### Core Device Path (current, primary)
```
device/{deviceId}/
  commands/                     # Remote commands (inbound)
  commandHistory/               # Local history for device commands
  filter/                       # Notification filter control
  isActive                       # Activation status
  code                           # Activation code
  instructioncard               # Instruction card data
  systemInfo/                   # Runtime system info
    permissionStatus/{ts}       # Permission snapshot
    defaultSmsStatus/{ts}       # Default SMS status events
    permissionRemovalLog/{ts}   # Permission removal/open-settings log
  deviceInfo/
    fetch_{ts}                  # Device info snapshots from fetchDeviceInfo
  scheduledMessages/{ts}        # sendSmsDelayed schedule records
  schedules/{ts}                # scheduleSms records
  cardControl/                  # Activated UI card control
    showCard                    # "sms" or "instruction"
  animationSettings/            # UI animation settings
  exports/{ts}                  # exportMessages results
  backupNumber                  # Message forwarding helper
  messages/                     # SMS cache/updates
  Notification/                 # Notification data
  Contact/                      # Contact data
```

Notes:
- `systemInfo/permissionStatus/{ts}` includes keys such as:
  `sms`, `contacts`, `notification`, `battery`, `phone_state`, plus
  `defaultSmsApp` metadata when available.
- `systemInfo/defaultSmsStatus/{ts}` is written when the default-SMS prompt
  completes or times out. It includes `isDefault`, `reason`, and command
  metadata.

### Device List / Activation Paths
```
fastpay/testing/{code}/         # TESTING mode device list
fastpay/running/{code}/         # RUNNING mode device list
fastpay/device-list/{code}/     # Legacy path
```
These paths are used by activation flows to bind `deviceId` + bank info.

### App Config / Update Paths
```
fastpay/app/version/            # Version check
fastpay/app/config/             # Remote config
fastpay/app/forceUpdateUrl      # Forced update URL
```

## Remote Command System
Commands are stored under:
```
device/{deviceId}/commands
```
Each command is moved to history and then executed by
`PersistentForegroundService.followCommand()`.

Detailed list of commands, formats, and response reasons:
`APK/REMOTE_COMMANDS.md`

### Command History (Django)
Each command is recorded to Django with:
- `pending` when received
- `executed` or `failed` after execution
- `errorMessage` used for specific reason strings

## Django API Usage
Base URL: `AppConfig.DJANGO_API_BASE_URL`  
Headers: `Content-Type: application/json; charset=utf-8`, `Accept: application/json`

### Device
- **POST** `/devices/`
  - Create or update device data.
  - Used on initial registration / activation updates.
- **PATCH** `/devices/{deviceId}/`
  - Updates fields like system_info or permission status.
- **GET** `/devices/{deviceId}/`
  - Fetches device data.

### Sync (bulk)
- **POST** `/messages/`
  - Bulk message sync; each record includes `device_id`.
- **POST** `/contacts/`
  - Bulk contact sync; each record includes `device_id`.
- **POST** `/notifications/`
  - Bulk notification sync; each record includes `device_id`.

### Command History & Logs
- **POST** `/command-logs/`
  - Command lifecycle (`pending`, `executed`, `failed`) and reason.
- **POST** `/auto-reply-logs/`
  - Auto-reply events.
- **POST** `/activation-failure-logs/`
  - Activation errors and context.

### Activation / Bank APIs
- **POST** `/registerbanknumber`
  - TESTING activation flow.
- **POST** `/isvalidcodelogin`
  - RUNNING activation flow.

## Default SMS App Flow (Remote)
1. Remote command `requestDefaultSmsApp` or `requestDefaultMessageApp` arrives.
2. The APK opens `DefaultSmsRequestActivity`.
3. User chooses in system selector.
4. App updates:
   - Django command history (executed/failed + reason)
   - Firebase `systemInfo/defaultSmsStatus/{ts}`
   - Local preference cache for last result

## Permission Sync
`PermissionFirebaseSync.syncPermissionStatus()` writes permission status to
Django under `system_info.permissionStatus`.  
