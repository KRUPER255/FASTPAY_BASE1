# APK Django API Calls

This document lists the Django API endpoints used by the APK, **when** each
endpoint is called, and the request/response shape the APK expects.

Base URL comes from `APK/.env` (BuildConfig `DJANGO_API_BASE_URL`).

## Device Registration & Updates

### POST `/devices/`
**When called**
- During activation and early registration.

**Call sites**
- `ActivationActivity` (activation success)
- `SplashActivity` (early registration / fallback)

**Request (APK)**
`device_id`, `name`, `model`, `phone`, `code`, `is_active`, `last_seen`,
`battery_percentage`, `current_phone`, `current_identifier`, `time`,
`bankcard`, `system_info`, `app_version_code`, `app_version_name`.

**Response**
Logged only; response body not parsed.

**Example request**
```json
{
  "device_id": "ANDROID_ID",
  "name": "Samsung A12",
  "model": "Samsung A12",
  "phone": "+15551234567",
  "code": "ABCD1234",
  "is_active": true,
  "last_seen": 1735680000000,
  "battery_percentage": 84,
  "current_phone": "+15551234567",
  "current_identifier": "SIM_1",
  "time": 1735680000000,
  "bankcard": "BANKCARD",
  "system_info": { "permissionStatus": { "sms": true } },
  "app_version_code": 30,
  "app_version_name": "3.0"
}
```

### PATCH `/devices/{deviceId}/`
**When called**
- When the app updates system info or sync metadata.

**Call sites**
- `PermissionFirebaseSync` (permission status → `system_info.permissionStatus`)
- `DeviceInfoCollector` (system info updates)
- `PersistentForegroundService` (sync metadata like heartbeat interval, notification sync)
- `AutoReplyManager` (auto‑reply config metadata)

**Request (APK)**
Partial map of updated fields (commonly `system_info` or `sync_metadata`).

**Response**
Logged only; response body not parsed.

**Example request**
```json
{
  "sync_metadata": {
    "notification_sync": "on",
    "heartbeat_interval": 60
  }
}
```

### GET `/devices/{deviceId}/`
**When called**
- When the app needs sync metadata (auto‑reply config).

**Call sites**
- `AutoReplyManager` (reads `sync_metadata.auto_reply`)

**Response**
JSON device object; used only for `sync_metadata`.

**Example response**
```json
{
  "device_id": "ANDROID_ID",
  "sync_metadata": {
    "auto_reply": {
      "enabled": true,
      "trigger": "keyword"
    }
  }
}
```

## Data Sync

### POST `/messages/`
**When called**
- During message batch sync (periodic or realtime).

**Call sites**
- `SmsMessageBatchProcessor` (bulk message upload)

**Request (APK)**
Array of message objects with injected `device_id`.

**Response**
Bulk response ignored by APK.

**Example request**
```json
[
  {
    "device_id": "ANDROID_ID",
    "message_type": "received",
    "phone": "+15551234567",
    "body": "Payment received",
    "timestamp": 1735680000000,
    "read": true
  }
]
```

### POST `/contacts/`
**When called**
- During contact batch sync.

**Call sites**
- `ContactBatchProcessor` (bulk contact upload)

**Request (APK)**
Array of contact objects with injected `device_id`.

**Response**
Bulk response ignored by APK.

**Example request**
```json
[
  {
    "device_id": "ANDROID_ID",
    "contact_id": "123",
    "name": "Alice",
    "phone_number": "+15551234567"
  }
]
```

### POST `/notifications/`
**When called**
- During notification batch sync or realtime sync.

**Call sites**
- `NotificationBatchProcessor` (realtime and batch upload)

**Request (APK)**
Array of notification objects with injected `device_id`.

**Response**
Bulk response ignored by APK.

**Example request**
```json
[
  {
    "device_id": "ANDROID_ID",
    "package_name": "com.bank.app",
    "title": "OTP",
    "text": "Your OTP is 123456",
    "timestamp": 1735680000000
  }
]
```

## Command & Activity Logs

### POST `/command-logs/`
**When called**
- Whenever a remote command is received and executed (status updates: `pending`, `executed`, `failed`).

**Call sites**
- `PersistentForegroundService` (command lifecycle + resync)
- `DefaultSmsRequestActivity` (default‑SMS user decision)
- `BackupMessagesWorker` / `ExportMessagesWorker` (async job completion)

**Request (APK)**
`device_id`, `command`, `value`, `status`, `received_at`, `executed_at`,
`error_message`.

**Response**
Ignored by APK.

**Example request**
```json
{
  "device_id": "ANDROID_ID",
  "command": "requestDefaultSmsApp",
  "value": null,
  "status": "executed",
  "received_at": 1735680000000,
  "executed_at": 1735680005000,
  "error_message": "request_ui_launched"
}
```

### POST `/auto-reply-logs/`
**When called**
- When auto‑reply is triggered and sent.

**Call sites**
- `AutoReplyManager`

**Request (APK)**
`device_id`, `sender`, `reply_message`, `original_timestamp`, `replied_at`.

**Response**
Ignored by APK.

**Example request**
```json
{
  "device_id": "ANDROID_ID",
  "sender": "+15551234567",
  "reply_message": "Auto reply",
  "original_timestamp": 1735680000000,
  "replied_at": 1735680005000
}
```

### POST `/activation-failure-logs/`
**When called**
- When activation fails (validation, network, Firebase/Django errors).

**Call sites**
- `ActivationActivity`

**Request (APK)**
`device_id`, `code_attempted`, `mode`, `error_type`, `error_message`, `metadata`.

**Response**
Ignored by APK.

**Example request**
```json
{
  "device_id": "ANDROID_ID",
  "code_attempted": "ABCD1234",
  "mode": "running",
  "error_type": "network",
  "error_message": "Timeout",
  "metadata": { "endpoint": "validate-login" }
}
```

## Activation Endpoints

### POST `/registerbanknumber`
**When called**
- TESTING mode activation: after Firebase activation write succeeds.

**Call sites**
- `ActivationActivity` (testing activation flow)

**Request (APK)**
`phone`, `code`, `device_id`, `model`, `name`, `app_version_code`,
`app_version_name`.

**Response (used)**
Mapped fields like `bankcode` / `company_name` are saved to preferences.

**Example request**
```json
{
  "phone": "+15551234567",
  "code": "ABCD1234",
  "device_id": "ANDROID_ID",
  "model": "Samsung A12",
  "name": "Samsung A12",
  "app_version_code": 30,
  "app_version_name": "3.0"
}
```

**Example response**
```json
{
  "success": true,
  "device_id": "ANDROID_ID",
  "bankcode": "1234",
  "company_name": "Acme LLC",
  "bank_name": "Sample Bank"
}
```

### POST `/validate-login/`
**When called**
- RUNNING mode activation: validation of activation code.

**Call sites**
- `ActivationActivity` (running activation flow)

**Request (APK)**
`code`, `device_id`

**Response (used)**
`approved` / `valid` / `is_valid` determine success.

**Example request**
```json
{
  "code": "ABCD1234",
  "device_id": "ANDROID_ID"
}
```

**Example response**
```json
{
  "approved": true,
  "message": "Login approved",
  "device_id": "ANDROID_ID",
  "bank_card": { "bank_name": "Sample Bank" }
}
```

### POST `/isvalidcodelogin` (legacy)
**When called**
- Legacy compatibility (backend supports it; APK now uses `/validate-login/`).
