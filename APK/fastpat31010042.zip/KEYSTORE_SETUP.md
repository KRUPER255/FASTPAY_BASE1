# Keystore Setup Instructions

## Overview

For security reasons, keystore credentials are no longer stored in `build.gradle.kts`. Instead, they are loaded from a `keystore.properties` file that is excluded from version control.

## Setup Steps

### 1. Create keystore.properties file

Copy the template file to create your actual keystore properties:

```bash
cp keystore.properties.template keystore.properties
```

### 2. Fill in your credentials

Edit `keystore.properties` and fill in your actual keystore information:

```properties
KEYSTORE_FILE=release.keystore
KEYSTORE_PASSWORD=your_actual_password
KEY_ALIAS=your_actual_alias
KEY_PASSWORD=your_actual_key_password
```

### 3. Verify .gitignore

Ensure `keystore.properties` is in `.gitignore` (it should already be there). This file should **NEVER** be committed to version control.

### 4. Build the project

After setting up `keystore.properties`, you can build the release APK as usual:

```bash
./gradlew assembleRelease
```

## Important Notes

- **Never commit `keystore.properties`** - It contains sensitive credentials
- **Keep your keystore file secure** - Store it in a safe location
- **Backup your keystore** - If you lose it, you cannot update your app on Google Play
- **For team members**: Each developer should create their own `keystore.properties` from the template

## Troubleshooting

### Build fails with "keystore.properties not found"

This is expected for debug builds. For release builds, you must create `keystore.properties` as described above.

### Build fails with "keystore file not found"

Ensure the `KEYSTORE_FILE` path in `keystore.properties` is correct. It can be:
- Relative to the `app/` directory: `release.keystore`
- Absolute path: `/path/to/your/release.keystore`

### Build fails with authentication errors

Verify that:
1. `KEYSTORE_PASSWORD` matches your keystore password
2. `KEY_ALIAS` matches your key alias
3. `KEY_PASSWORD` matches your key password

## Security Best Practices

1. ✅ Use strong passwords for keystore and key
2. ✅ Store keystore file in a secure location (not in the project directory)
3. ✅ Use environment variables in CI/CD instead of files
4. ✅ Rotate keystore credentials periodically
5. ✅ Limit access to keystore credentials to trusted team members only
