# FastPay Android Application

[![Version](https://img.shields.io/badge/version-3.0-blue.svg)](https://github.com/your-repo)
[![Min SDK](https://img.shields.io/badge/min%20SDK-27-green.svg)](https://developer.android.com)
[![Target SDK](https://img.shields.io/badge/target%20SDK-36-orange.svg)](https://developer.android.com)
[![Kotlin](https://img.shields.io/badge/kotlin-2.0.21-purple.svg)](https://kotlinlang.org)

FastPay is an Android application for device management, SMS handling, and remote control capabilities with Firebase Realtime Database integration.

## 🚀 Quick Start

### Prerequisites
- Android Studio Hedgehog or later
- JDK 11 or later
- Android SDK 27+
- Gradle 8.13.2+

### Setup

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd FASTPAY/APK
   ```

2. **Set up keystore** (for release builds)
   ```bash
   cp keystore.properties.template keystore.properties
   # Edit keystore.properties with your credentials
   ```
   See [KEYSTORE_SETUP.md](./KEYSTORE_SETUP.md) for details.

3. **Enable Firebase Crashlytics**
   - Go to [Firebase Console](https://console.firebase.google.com/)
   - Select project: `test74-51b5e`
   - Navigate to **Build** > **Crashlytics** > **Enable**

4. **Sync Gradle**
   ```bash
   ./gradlew build --refresh-dependencies
   ```

5. **Build the project**
   ```bash
   ./gradlew assembleDebug    # Debug build
   ./gradlew assembleRelease  # Release build (requires keystore.properties)
   ```

## 📚 Documentation

### Getting Started
- [Manual Setup Required](./MANUAL_SETUP_REQUIRED.md) - **Read this first!**
- [Quick Start Guide](./QUICK_START_COMPLETE.md) - Quick reference
- [Project Documentation](./PROJECT_COMPLETE_DOCUMENTATION.md) - Complete project docs

### Development Guides
- [Implementation Plan](./IMPLEMENTATION_PLAN.md) - Detailed task breakdown
- [Improvements List](./IMPROVEMENTS.md) - Codebase improvements
- [Progress Summary](./PROGRESS_SUMMARY.md) - What's been done

### Framework Guides
- [Logging Migration Guide](./LOGGING_MIGRATION_GUIDE.md) - How to use Logger
- [Error Handling Guide](./ERROR_HANDLING_GUIDE.md) - Error handling patterns
- [Testing Setup](./TESTING_SETUP.md) - Testing framework
- [Hilt Setup Guide](./HILT_SETUP_GUIDE.md) - Dependency injection

### Setup Instructions
- [Keystore Setup](./KEYSTORE_SETUP.md) - Keystore configuration
- [Testing Setup](./TESTING_SETUP.md) - Testing framework setup

## 🏗️ Architecture

- **Pattern**: MVVM (Model-View-ViewModel)
- **Dependency Injection**: Hilt
- **Language**: Kotlin
- **Min SDK**: 27 (Android 8.1)
- **Target SDK**: 36 (Android 15)

## 🛠️ Key Features

### Implemented
- ✅ Unified logging system (Logger/Timber)
- ✅ Error handling framework (Result pattern)
- ✅ Crash reporting (Firebase Crashlytics)
- ✅ Testing framework (MockK, Truth, Turbine, etc.)
- ✅ Dependency injection (Hilt)
- ✅ Secure keystore management

### In Progress
- ⏳ Repository pattern migration
- ⏳ Navigation Component
- ⏳ Unit test coverage
- ⏳ Logging migration (remaining files)

## 📦 Project Structure

```
app/
├── src/
│   ├── main/
│   │   ├── java/com/example/fast/
│   │   │   ├── di/              # Dependency injection modules
│   │   │   ├── model/            # Data models
│   │   │   │   └── exceptions/  # Custom exceptions
│   │   │   ├── ui/               # Activities and UI components
│   │   │   └── util/             # Utility classes
│   │   │       ├── Logger.kt     # Unified logging
│   │   │       ├── Result.kt     # Error handling
│   │   │       └── ...
│   │   └── res/                  # Resources
│   └── test/                     # Unit tests
│   └── androidTest/              # Instrumentation tests
├── build.gradle.kts
└── proguard-rules.pro
```

## 🔧 Development

### Running Tests
```bash
./gradlew test                    # Unit tests
./gradlew connectedAndroidTest    # Instrumentation tests
```

### Building
```bash
./gradlew assembleDebug           # Debug APK
./gradlew assembleRelease         # Release APK
./gradlew bundleRelease           # App Bundle
```

### Code Quality
```bash
./gradlew lint                    # Run lint
./gradlew check                   # Run all checks
```

## 📝 Recent Improvements

See [PROGRESS_SUMMARY.md](./PROGRESS_SUMMARY.md) for a complete list of recent improvements.

### Latest Updates
- ✅ Keystore security improvements
- ✅ Firebase Crashlytics integration
- ✅ Unified logging system
- ✅ Error handling framework
- ✅ Testing framework setup
- ✅ Hilt dependency injection

## 🤝 Contributing

1. Review the [Implementation Plan](./IMPLEMENTATION_PLAN.md)
2. Check [Improvements List](./IMPROVEMENTS.md) for areas needing work
3. Follow the migration guides for framework adoption
4. Write tests for new features
5. Update documentation

## 📄 License

[Add your license information here]

## 🔗 Related Documentation

- [Backend Documentation](../BACKEND/README.md)
- [Dashboard Documentation](../DASHBOARD/README.md)

## 📞 Support

For issues and questions:
- Check [MANUAL_SETUP_REQUIRED.md](./MANUAL_SETUP_REQUIRED.md) for setup issues
- Review [PROJECT_COMPLETE_DOCUMENTATION.md](./PROJECT_COMPLETE_DOCUMENTATION.md) for feature documentation
- See [IMPLEMENTATION_PLAN.md](./IMPLEMENTATION_PLAN.md) for development roadmap

---

**Last Updated**: January 26, 2026  
**Version**: 3.0 (versionCode: 30)
