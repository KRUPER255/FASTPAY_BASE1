# Code Style Guide

## Overview

This guide establishes coding standards and best practices for the FastPay Android application.

## Kotlin Style

### Naming Conventions

#### Classes and Objects
```kotlin
// ✅ Good
class MainActivity : AppCompatActivity()
object FirebaseHelper

// ❌ Bad
class mainActivity
object firebase_helper
```

#### Functions
```kotlin
// ✅ Good
fun getUserData(): UserData
fun sendSms(phoneNumber: String, message: String)

// ❌ Bad
fun GetUserData()
fun send_sms()
```

#### Variables
```kotlin
// ✅ Good
val userName: String
var isActive: Boolean
private val viewModel: MainViewModel

// ❌ Bad
val user_name
var IsActive
private val mViewModel
```

#### Constants
```kotlin
// ✅ Good
const val MAX_RETRY_COUNT = 3
object Constants {
    const val API_TIMEOUT = 5000L
}

// ❌ Bad
val maxRetryCount = 3
const val api_timeout = 5000L
```

### Code Organization

#### File Structure
```kotlin
package com.example.fast

// 1. Imports (grouped)
import android.content.Context
import android.os.Bundle

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope

import com.example.fast.util.Logger
import com.example.fast.model.User

// 2. Class/Interface documentation
/**
 * Class description
 */
class MyClass {
    // 3. Companion object (if any)
    companion object {
        const val TAG = "MyClass"
    }
    
    // 4. Properties
    private val property: String
    
    // 5. Constructor
    constructor() {
        // ...
    }
    
    // 6. Functions (public first, then private)
    fun publicFunction() {
        // ...
    }
    
    private fun privateFunction() {
        // ...
    }
}
```

### Formatting

#### Indentation
- Use 4 spaces (not tabs)
- Consistent indentation throughout

#### Line Length
- Maximum 100 characters per line
- Break long lines appropriately

#### Blank Lines
- One blank line between functions
- Two blank lines between classes
- Group related code together

### Best Practices

#### Use `val` over `var`
```kotlin
// ✅ Good
val userName = "John"

// ❌ Bad (unless necessary)
var userName = "John"
```

#### Use Expression Bodies
```kotlin
// ✅ Good
fun getCount(): Int = items.size

// ❌ Bad
fun getCount(): Int {
    return items.size
}
```

#### Use String Templates
```kotlin
// ✅ Good
val message = "Hello, $name!"

// ❌ Bad
val message = "Hello, " + name + "!"
```

#### Use Safe Calls
```kotlin
// ✅ Good
val length = text?.length

// ❌ Bad
val length = if (text != null) text.length else null
```

#### Use `when` over `if-else`
```kotlin
// ✅ Good
when (status) {
    "active" -> handleActive()
    "inactive" -> handleInactive()
    else -> handleUnknown()
}

// ❌ Bad
if (status == "active") {
    handleActive()
} else if (status == "inactive") {
    handleInactive()
} else {
    handleUnknown()
}
```

## Android-Specific

### Activities
```kotlin
@AndroidEntryPoint
class MainActivity : AppCompatActivity() {
    
    private val viewModel: MainViewModel by viewModels()
    private lateinit var binding: ActivityMainBinding
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }
}
```

### ViewModels
```kotlin
@HiltViewModel
class MainViewModel @Inject constructor(
    private val repository: MyRepository
) : ViewModel() {
    
    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()
    
    fun loadData() {
        viewModelScope.launch {
            // ...
        }
    }
}
```

### Logging
```kotlin
// ✅ Good
Logger.d("Tag", "Debug message")
Logger.e("Tag", exception, "Error message")

// ❌ Bad
Log.d("Tag", "Debug message")
println("Debug message")
```

### Error Handling
```kotlin
// ✅ Good
val result = someOperation()
result.onSuccess { data ->
    // Handle success
}.onError { exception ->
    Logger.e("Tag", exception, "Operation failed")
    // Handle error
}

// ❌ Bad
try {
    val data = someOperation()
    // Handle success
} catch (e: Exception) {
    Log.e("Tag", "Error", e)
}
```

## Documentation

### KDoc Comments
```kotlin
/**
 * Sends an SMS message to the specified phone number.
 * 
 * @param phoneNumber The recipient's phone number
 * @param message The message text to send
 * @return Result indicating success or failure
 * @throws SmsException if sending fails
 */
suspend fun sendSms(phoneNumber: String, message: String): Result<Unit>
```

### Inline Comments
```kotlin
// ✅ Good - explains why, not what
// Check if user has permission before accessing contacts
if (hasPermission) {
    // ...
}

// ❌ Bad - states the obvious
// Set isActive to true
isActive = true
```

## Testing

### Test Naming
```kotlin
// ✅ Good
@Test
fun `test user login with valid credentials`() {
    // ...
}

@Test
fun `test user login with invalid password`() {
    // ...
}

// ❌ Bad
@Test
fun test1() {
    // ...
}
```

### Test Structure
```kotlin
@Test
fun `test description`() {
    // Arrange
    val input = "test"
    
    // Act
    val result = functionUnderTest(input)
    
    // Assert
    assertThat(result).isEqualTo("expected")
}
```

## Resources

### String Resources
```kotlin
// ✅ Good
val message = getString(R.string.welcome_message)

// ❌ Bad
val message = "Welcome!"
```

### Constants
```kotlin
// ✅ Good
val transitionName = Constants.Transitions.LOGO

// ❌ Bad
val transitionName = "logo_transition"
```

## Git Commit Messages

### Format
```
type(scope): subject

body (optional)

footer (optional)
```

### Types
- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation
- `style`: Code style changes
- `refactor`: Code refactoring
- `test`: Adding tests
- `chore`: Maintenance tasks

### Examples
```
feat(sms): Add bulk SMS sending capability

fix(firebase): Resolve timeout issue in Firebase reads

docs(readme): Update setup instructions

refactor(repository): Extract Firebase operations to repository
```

---

**Last Updated**: January 26, 2026
